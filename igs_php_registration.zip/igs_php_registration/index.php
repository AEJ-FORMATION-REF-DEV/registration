﻿<?php
	// Initialiser la session
	session_start();
	// Vérifiez si l'utilisateur est connecté, sinon redirigez-le vers la page de connexion
	if(!isset($_SESSION["firstname"])){
		header("Location: connexion.php");
		exit(); 
	}
?>
<!DOCTYPE html>
<html>
	<head>
			<meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="author" content="Michael"/>

            <link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" rel="stylesheet" />
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
            <title>Home</title>
			<link rel="stylesheet" href="style.css" />
	</head>
	<body>
		<div class="sucess">
			<h1>Bienvenue <?php echo $_SESSION['firstname']; ?>!</h1>
			<p>C'est votre tableau de bord.</p>
			<a href="deconnexion.php">Déconnexion</a>
		</div>
	</body>
</html>