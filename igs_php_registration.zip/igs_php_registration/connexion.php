﻿<!DOCTYPE html>
<html>
<head>
			<meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="author" content="Michael"/>

            <link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" rel="stylesheet" />
			
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

            <title>Connexion</title>
	
			
			<link rel="stylesheet" href="style.css" />
</head>
<body>

<?php
	require('config.php'); 

	session_start();

		if (isset($_POST['firstname'])){
			$firstname = stripslashes($_REQUEST['firstname']);
			$firstname = mysqli_real_escape_string($conn, $firstname);

			$password = stripslashes($_REQUEST['password']);
			$password = mysqli_real_escape_string($conn, $password);

			$query = "SELECT * FROM `users` WHERE firstname='$firstname' and password='".hash('sha256', $password)."'";
			$result = mysqli_query($conn,$query) or die(mysql_error());
			$rows = mysqli_num_rows($result);
			if($rows==1){
				$_SESSION['firstname'] = $firstname;
				header("Location: index.php");
			}else{
				$message = "Le nom d'utilisateur ou le mot de passe est incorrect.";
			}
		}
		?>



		<form class="box" action="" method="post" name="login">
		<h1 class="box-logo box-title"><a href="#">Vous être la Bienvenu sur notre page</a></h1>
		<h1 class="box-title">Connexion</h1>
		<div class="form-group">
			<input type="text" class="form-control" name="firstname" placeholder="Nom" required="required" autocomplete="off">
		</div>
		<div class="form-group">
			<input type="password" class="form-control" name="password" placeholder="Mot de passe" required="required" autocomplete="off">
		</div>
		
		<input type="submit" value="Connexion" name="submit"  class="btn btn-primary btn-block" />
		
		
		<p class="box-register">N'avez vous pas un compte <a href="inscription.php">S'inscrire</a></p>
		
		<?php if (!empty($message)) { ?>
			<p class="errorMessage"><?php echo $message; ?></p>
		<?php } ?>

		</form>
</body>
</html>