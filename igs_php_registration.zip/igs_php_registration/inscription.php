﻿<!DOCTYPE html>
<html>
<head>
			<meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="author" content="Michael"/>

            <link href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css" rel="stylesheet" />
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
            <title>Inscription</title>
			<link rel="stylesheet" href="style.css" />
</head>
<body>
	<?php
	require('config.php');
	if (isset($_REQUEST['firstname'], $_REQUEST['lastname'], $_REQUEST['tel'], $_REQUEST['email'], $_REQUEST['password'])){
		// récupérer le nom d'utilisateur et supprimer les antislashes ajoutés par le formulaire
		$firstname = stripslashes($_REQUEST['firstname']);
		$firstname = mysqli_real_escape_string($conn, $firstname); 
		// récupérer le nom d'utilisateur et supprimer les antislashes ajoutés par le formulaire
		$lastname = stripslashes($_REQUEST['lastname']);
		$lastname = mysqli_real_escape_string($conn, $lastname);
		// récupérer le nom d'utilisateur et supprimer les antislashes ajoutés par le formulaire
		$tel = stripslashes($_REQUEST['tel']);
		$tel = mysqli_real_escape_string($conn, $tel);
		// récupérer l'email et supprimer les antislashes ajoutés par le formulaire
		$email = stripslashes($_REQUEST['email']);
		$email = mysqli_real_escape_string($conn, $email);
		// récupérer le mot de passe et supprimer les antislashes ajoutés par le formulaire
		$password = stripslashes($_REQUEST['password']);
		$password = mysqli_real_escape_string($conn, $password);
		//requéte SQL + mot de passe crypté
		$query = "INSERT into `users` (firstname, lastname, tel, email, password)
				VALUES ('$firstname', '$lastname', '$tel', '$email', '".hash('sha256', $password)."')";
		// Exécute la requête sur la base de données
		$res = mysqli_query($conn, $query);
		if($res){
		echo "<div class='sucess'>
				<h3>Bienvenue votre inscription a été effectué avec succès.</h3>
				<p>Cliquez ici pour vous <a href='connexion.php'>connecter</a></p>
				</div>";
			}

				if(isset($_GET['reg_err']))
                {
                    $err = htmlspecialchars($_GET['reg_err']);

                    switch($err)
                    {
                        case 'success':
                        ?>
                            <div class="alert alert-success">
                                <strong>Succès</strong> inscription réussie !
                            </div>
                        <?php
                        break;

                        case 'password':
                        ?>
                            <div class="alert alert-danger">
                                <strong>Erreur</strong> mot de passe différent
                            </div>
                        <?php
                        break;

                        case 'email':
                        ?>
                            <div class="alert alert-danger">
                                <strong>Erreur</strong> email non valide
                            </div>
                        <?php
                        break;

                        case 'email_length':
                        ?>
                            <div class="alert alert-danger">
                                <strong>Erreur</strong> email trop long
                            </div>
                        <?php 
                        break;

                        case 'pseudo_length':
                        ?>
                            <div class="alert alert-danger">
                                <strong>Erreur</strong> pseudo trop long
                            </div>
                        <?php 
                        case 'already':
                        ?>
                            <div class="alert alert-danger">
                                <strong>Erreur</strong> compte deja existant
                            </div>
                        <?php 

                    }
                }



		
	}else{
		?>
		
		<!--
		<form class="box" action="" method="post">
			<h1 class="box-logo box-title"><a href="#">Bienvenue sur la page</a></h1>
			<h1 class="box-title">S'inscrire</h1>
			<input type="text" class="box-input" name="firstname" placeholder="Nom" required />
			<input type="text" class="box-input" name="lastname" placeholder="Prenom" required />
			<input type="text" class="box-input" name="tel" placeholder="tel whatsapp" required />
			<input type="email" class="box-input" name="email" placeholder="Email" required />
			<input type="password" class="box-input" name="password" placeholder="Mot de passe" required />
			<input type="submit" name="submit" value="S'inscrire" class="box-button" />
			<p class="box-register">Déjà inscrit? <a href="login.php">Connectez-vous ici</a></p>
		</form>

		class="form-control"    required="required" autocomplete="off"
		-->
		<form class="box" action="" method="post">
				<h1 class="box-logo box-title"><a href="#">Bienvenue sur la page</a></h1>
				<h1 class="box-title">S'inscrire</h1>
                <div class="form-group">
					<input type="text" class="form-control" name="firstname" placeholder="Nom" required="required" autocomplete="off"/>
                </div>
                <div class="form-group">
					<input type="text" class="form-control" name="lastname" placeholder="Prenom" required="required" autocomplete="off"/>
                </div>
                <div class="form-group">
					<input type="text" class="form-control" name="tel" placeholder="tel whatsapp" required="required" autocomplete="off"/>
                </div>
                <div class="form-group">
					<input type="email" class="form-control" name="email" placeholder="Email" required="required" autocomplete="off"/>
                </div>
				<div class="form-group">
					<input type="password" class="form-control" name="password" placeholder="Mot de passe" required="required" autocomplete="off"/>
                </div>
				<div class="form-group">
                    <input type="password" name="password_retype" class="form-control" placeholder="Confirmation mot de passe" required="required" autocomplete="off">
                </div>
                
					<input type="submit" name="submit" value="S'inscrire" class="btn btn-primary btn-block" />
                   
				<p class="box-register">Déjà inscrit? <a href="connexion.php">Connectez-vous ici</a></p>
		</form>



		<?php 
	} ?>
</body>
</html>